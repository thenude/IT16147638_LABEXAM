package com.payment;

public class Payment {

}
